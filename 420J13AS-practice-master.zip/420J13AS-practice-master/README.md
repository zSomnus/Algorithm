# 420J13AS-practice
Practice for Advanced Data Structure (420J13AS)

![math](https://user-images.githubusercontent.com/6082364/51435768-9cc92c00-1c4d-11e9-9c71-9322256cb339.jpg)

## Shortcuts reminder
* Alt + Enter: Quick fix (most important shortcut of your life)
* Ctrl + F5: Run project and see console output
* Ctrl + R, A: Run all tests

![shortcuts](https://blogs.msmvps.com/kenlin/files/2017/03/VS2017_Shortcuts.2.png)
